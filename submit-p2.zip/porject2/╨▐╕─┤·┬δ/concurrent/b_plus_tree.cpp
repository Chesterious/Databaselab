#include <string>
#include <stack>
#include <functional>

#include "common/exception.h"
#include "common/logger.h"
#include "common/rid.h"
#include "storage/index/b_plus_tree.h"
#include "storage/page/header_page.h"

namespace bustub {
INDEX_TEMPLATE_ARGUMENTS
BPLUSTREE_TYPE::BPlusTree(std::string name, BufferPoolManager *buffer_pool_manager, const KeyComparator &comparator,
                          int leaf_max_size, int internal_max_size)
    : index_name_(std::move(name)),
      root_page_id_(INVALID_PAGE_ID),
      buffer_pool_manager_(buffer_pool_manager),
      comparator_(comparator),
      leaf_max_size_(leaf_max_size),
      internal_max_size_(internal_max_size) {}

INDEX_TEMPLATE_ARGUMENTS
auto BPLUSTREE_TYPE::IsEmpty() const -> bool { 
  return root_page_id_ == INVALID_PAGE_ID; 
}

INDEX_TEMPLATE_ARGUMENTS
auto BPLUSTREE_TYPE::GetValue(const KeyType &key, std::vector<ValueType> *result, Transaction *transaction) -> bool {
  // 搜索操作使用读锁
  root_page_id_latch_.RLock();
  Page *target_page = FindLeaf(key, Operation::SEARCH, transaction);
  LeafPage *leaf_data = reinterpret_cast<LeafPage *>(target_page->GetData());
  
  // 在叶节点中查找键
  ValueType found_value;
  bool exists = leaf_data->Lookup(key, &found_value, comparator_);
  
  // 清理资源
  target_page->RUnlatch();
  buffer_pool_manager_->UnpinPage(target_page->GetPageId(), false);
  
  if (exists) {
    result->push_back(found_value);
    return true;
  }
  return false;
}

INDEX_TEMPLATE_ARGUMENTS
auto BPLUSTREE_TYPE::Insert(const KeyType &key, const ValueType &value, Transaction *transaction) -> bool {
  // 插入需要写锁保护根节点
  root_page_id_latch_.WLock();
  transaction->AddIntoPageSet(nullptr);
  
  // 空树初始化
  if (root_page_id_ == INVALID_PAGE_ID) {
    StartNewTree(key, value);
    ReleaseLatchFromQueue(transaction);
    return true;
  }
  
  // 插入到现有树中
  bool success = InsertIntoLeaf(key, value, transaction);
  return success;
}

INDEX_TEMPLATE_ARGUMENTS
void BPLUSTREE_TYPE::StartNewTree(const KeyType &key, const ValueType &value) {
  // 创建新的根叶节点
  page_id_t new_root;
  Page *root_page = buffer_pool_manager_->NewPage(&new_root);
  if (root_page == nullptr) {
    throw Exception(ExceptionType::OUT_OF_MEMORY, "Failed to allocate new page");
  }
  
  root_page_id_ = new_root;
  LeafPage *root_leaf = reinterpret_cast<LeafPage *>(root_page->GetData());
  root_leaf->Init(root_page_id_, INVALID_PAGE_ID, leaf_max_size_);
  root_leaf->Insert(key, value, comparator_);
  
  buffer_pool_manager_->UnpinPage(root_page->GetPageId(), true);
}

INDEX_TEMPLATE_ARGUMENTS
auto BPLUSTREE_TYPE::InsertIntoLeaf(const KeyType &key, const ValueType &value, Transaction *transaction) -> bool {
  // 找到要插入的叶节点
  Page *leaf_page = FindLeaf(key, Operation::INSERT, transaction);
  LeafPage *leaf_node = reinterpret_cast<LeafPage *>(leaf_page->GetData());
  
  // 记录插入前的大小
  int original_count = leaf_node->GetSize();
  
  // 尝试插入
  int new_count = leaf_node->Insert(key, value, comparator_);
  
  // 如果是重复键，直接返回
  if (new_count == original_count) {
    ReleaseLatchFromQueue(transaction);
    leaf_page->WUnlatch();
    buffer_pool_manager_->UnpinPage(leaf_page->GetPageId(), false);
    return false;
  }
  
  // 检查是否需要分裂
  if (new_count < leaf_max_size_) {
    // 叶节点未满，插入成功
    ReleaseLatchFromQueue(transaction);
    leaf_page->WUnlatch();
    buffer_pool_manager_->UnpinPage(leaf_page->GetPageId(), true);
    return true;
  }
  
  // 叶节点已满，需要分裂
  // 创建新的叶节点
  LeafPage *new_leaf = Split(leaf_node);
  
  // 维护叶节点链表
  new_leaf->SetNextPageId(leaf_node->GetNextPageId());
  leaf_node->SetNextPageId(new_leaf->GetPageId());
  
  // 获取新叶节点的第一个键作为分裂键
  KeyType split_key = new_leaf->KeyAt(0);
  
  // 将新节点插入到父节点
  InsertIntoParent(leaf_node, split_key, new_leaf, transaction);
  
  // 清理资源
  leaf_page->WUnlatch();
  buffer_pool_manager_->UnpinPage(leaf_page->GetPageId(), true);
  buffer_pool_manager_->UnpinPage(new_leaf->GetPageId(), true);
  
  return true;
}

INDEX_TEMPLATE_ARGUMENTS
template <typename N>
auto BPLUSTREE_TYPE::Split(N *node) -> N * {
  page_id_t new_page_id;
  Page *new_page = buffer_pool_manager_->NewPage(&new_page_id);
  
  if (new_page == nullptr) {
    throw Exception(ExceptionType::OUT_OF_MEMORY, "Cannot allocate new page for split");
  }
  
  N *new_node = reinterpret_cast<N *>(new_page->GetData());
  
  // 根据节点类型初始化
  if (node->IsLeafPage()) {
    LeafPage *old_leaf = reinterpret_cast<LeafPage *>(node);
    LeafPage *new_leaf = reinterpret_cast<LeafPage *>(new_node);
    
    new_leaf->Init(new_page_id, node->GetParentPageId(), leaf_max_size_);
    // 移动一半元素到新节点
    old_leaf->MoveHalfTo(new_leaf);
  } else {
    InternalPage *old_internal = reinterpret_cast<InternalPage *>(node);
    InternalPage *new_internal = reinterpret_cast<InternalPage *>(new_node);
    
    new_internal->Init(new_page_id, node->GetParentPageId(), internal_max_size_);
    // 移动一半元素到新节点，更新子节点父指针
    old_internal->MoveHalfTo(new_internal, buffer_pool_manager_);
  }
  
  return new_node;
}

INDEX_TEMPLATE_ARGUMENTS
void BPLUSTREE_TYPE::InsertIntoParent(BPlusTreePage *old_node, const KeyType &key, 
                                      BPlusTreePage *new_node, Transaction *transaction) {
  // 如果原节点是根节点，需要创建新根
  if (old_node->IsRootPage()) {
    page_id_t new_root_id;
    Page *root_page = buffer_pool_manager_->NewPage(&new_root_id);
    
    if (root_page == nullptr) {
      throw Exception(ExceptionType::OUT_OF_MEMORY, "Cannot allocate new root page");
    }
    
    root_page_id_ = new_root_id;
    InternalPage *root = reinterpret_cast<InternalPage *>(root_page->GetData());
    
    // 初始化新根节点
    root->Init(new_root_id, INVALID_PAGE_ID, internal_max_size_);
    root->PopulateNewRoot(old_node->GetPageId(), key, new_node->GetPageId());
    
    // 更新子节点的父指针
    old_node->SetParentPageId(new_root_id);
    new_node->SetParentPageId(new_root_id);
    
    buffer_pool_manager_->UnpinPage(root_page->GetPageId(), true);
    UpdateRootPageId(0);
    
    ReleaseLatchFromQueue(transaction);
    return;
  }
  
  // 获取父节点
  page_id_t parent_id = old_node->GetParentPageId();
  Page *parent_page = buffer_pool_manager_->FetchPage(parent_id);
  InternalPage *parent = reinterpret_cast<InternalPage *>(parent_page->GetData());
  
  // 如果父节点有空间，直接插入
  if (parent->GetSize() < internal_max_size_) {
    parent->InsertNodeAfter(old_node->GetPageId(), key, new_node->GetPageId());
    ReleaseLatchFromQueue(transaction);
    buffer_pool_manager_->UnpinPage(parent_page->GetPageId(), true);
    return;
  }
  
  // 父节点已满，需要分裂父节点
  // 使用栈来跟踪分裂过程
  std::stack<std::pair<InternalPage*, KeyType>> split_stack;
  
  // 临时复制父节点内容
  int temp_size = INTERNAL_PAGE_HEADER_SIZE + sizeof(MappingType) * (parent->GetSize() + 1);
  char *temp_buffer = new char[temp_size];
  InternalPage *temp_parent = reinterpret_cast<InternalPage *>(temp_buffer);
  
  // 复制原始数据
  std::memcpy(temp_buffer, parent_page->GetData(), 
              INTERNAL_PAGE_HEADER_SIZE + sizeof(MappingType) * parent->GetSize());
  
  // 在临时父节点中插入新条目
  temp_parent->InsertNodeAfter(old_node->GetPageId(), key, new_node->GetPageId());
  
  // 分裂临时父节点
  InternalPage *sibling_parent = Split(temp_parent);
  KeyType parent_split_key = sibling_parent->KeyAt(0);
  
  // 将部分数据复制回原父节点
  std::memcpy(parent_page->GetData(), temp_buffer,
              INTERNAL_PAGE_HEADER_SIZE + sizeof(MappingType) * temp_parent->GetMinSize());
  
  // 递归处理父节点的分裂
  InsertIntoParent(parent, parent_split_key, sibling_parent, transaction);
  
  // 清理临时资源
  delete[] temp_buffer;
  buffer_pool_manager_->UnpinPage(parent_page->GetPageId(), true);
  buffer_pool_manager_->UnpinPage(sibling_parent->GetPageId(), true);
}

INDEX_TEMPLATE_ARGUMENTS
void BPLUSTREE_TYPE::Remove(const KeyType &key, Transaction *transaction) {
  // 删除需要写锁
  root_page_id_latch_.WLock();
  transaction->AddIntoPageSet(nullptr);
  
  if (root_page_id_ == INVALID_PAGE_ID) {
    ReleaseLatchFromQueue(transaction);
    return;
  }
  
  // 找到包含键的叶节点
  Page *leaf_page = FindLeaf(key, Operation::DELETE, transaction);
  LeafPage *leaf = reinterpret_cast<LeafPage *>(leaf_page->GetData());
  
  // 尝试删除键
  int before_delete = leaf->GetSize();
  int after_delete = leaf->RemoveAndDeleteRecord(key, comparator_);
  
  // 如果键不存在，直接返回
  if (before_delete == after_delete) {
    ReleaseLatchFromQueue(transaction);
    leaf_page->WUnlatch();
    buffer_pool_manager_->UnpinPage(leaf_page->GetPageId(), false);
    return;
  }
  
  // 检查是否需要调整树结构
  bool should_delete_leaf = CoalesceOrRedistribute(leaf, transaction);
  leaf_page->WUnlatch();
  
  if (should_delete_leaf) {
    transaction->AddIntoDeletedPageSet(leaf->GetPageId());
  }
  
  buffer_pool_manager_->UnpinPage(leaf_page->GetPageId(), true);
  
  // 执行实际的页面删除
  for (page_id_t page_to_delete : *transaction->GetDeletedPageSet()) {
    buffer_pool_manager_->DeletePage(page_to_delete);
  }
  transaction->GetDeletedPageSet()->clear();
}

INDEX_TEMPLATE_ARGUMENTS
template <typename N>
auto BPLUSTREE_TYPE::CoalesceOrRedistribute(N *node, Transaction *transaction) -> bool {
  // 根节点特殊处理
  if (node->IsRootPage()) {
    bool delete_root = AdjustRoot(node);
    ReleaseLatchFromQueue(transaction);
    return delete_root;
  }
  
  // 如果节点足够大，不需要调整
  if (node->GetSize() >= node->GetMinSize()) {
    ReleaseLatchFromQueue(transaction);
    return false;
  }
  
  // 获取父节点信息
  page_id_t parent_id = node->GetParentPageId();
  Page *parent_page = buffer_pool_manager_->FetchPage(parent_id);
  InternalPage *parent = reinterpret_cast<InternalPage *>(parent_page->GetData());
  
  int node_position = parent->ValueIndex(node->GetPageId());
  
  // 尝试从左兄弟节点借用元素
  if (node_position > 0) {
    page_id_t left_sibling_id = parent->ValueAt(node_position - 1);
    Page *left_page = buffer_pool_manager_->FetchPage(left_sibling_id);
    left_page->WLatch();
    N *left_sibling = reinterpret_cast<N *>(left_page->GetData());
    
    if (left_sibling->GetSize() > left_sibling->GetMinSize()) {
      // 从左兄弟重新分配元素
      Redistribute(left_sibling, node, parent, node_position, true);
      ReleaseLatchFromQueue(transaction);
      
      buffer_pool_manager_->UnpinPage(parent_page->GetPageId(), true);
      left_page->WUnlatch();
      buffer_pool_manager_->UnpinPage(left_page->GetPageId(), true);
      return false;
    }
    
    // 合并到左兄弟
    bool delete_parent = Coalesce(left_sibling, node, parent, node_position, transaction);
    
    if (delete_parent) {
      transaction->AddIntoDeletedPageSet(parent->GetPageId());
    }
    
    buffer_pool_manager_->UnpinPage(parent_page->GetPageId(), true);
    left_page->WUnlatch();
    buffer_pool_manager_->UnpinPage(left_page->GetPageId(), true);
    return true;
  }
  
  // 尝试从右兄弟节点借用元素
  if (node_position < parent->GetSize() - 1) {
    page_id_t right_sibling_id = parent->ValueAt(node_position + 1);
    Page *right_page = buffer_pool_manager_->FetchPage(right_sibling_id);
    right_page->WLatch();
    N *right_sibling = reinterpret_cast<N *>(right_page->GetData());
    
    if (right_sibling->GetSize() > right_sibling->GetMinSize()) {
      // 从右兄弟重新分配元素
      Redistribute(right_sibling, node, parent, node_position, false);
      ReleaseLatchFromQueue(transaction);
      
      buffer_pool_manager_->UnpinPage(parent_page->GetPageId(), true);
      right_page->WUnlatch();
      buffer_pool_manager_->UnpinPage(right_page->GetPageId(), true);
      return false;
    }
    
    // 合并右兄弟到当前节点
    int right_position = parent->ValueIndex(right_sibling->GetPageId());
    bool delete_parent = Coalesce(node, right_sibling, parent, right_position, transaction);
    
    transaction->AddIntoDeletedPageSet(right_sibling->GetPageId());
    if (delete_parent) {
      transaction->AddIntoDeletedPageSet(parent->GetPageId());
    }
    
    buffer_pool_manager_->UnpinPage(parent_page->GetPageId(), true);
    right_page->WUnlatch();
    buffer_pool_manager_->UnpinPage(right_page->GetPageId(), true);
    return false;
  }
  
  // 特殊情况处理
  buffer_pool_manager_->UnpinPage(parent_page->GetPageId(), false);
  return false;
}

INDEX_TEMPLATE_ARGUMENTS
template <typename N>
auto BPLUSTREE_TYPE::Coalesce(N *neighbor_node, N *node,
                              BPlusTreeInternalPage<KeyType, page_id_t, KeyComparator> *parent,
                              int index, Transaction *transaction) -> bool {
  KeyType middle_key = parent->KeyAt(index);
  
  // 根据节点类型合并
  if (node->IsLeafPage()) {
    LeafPage *leaf = reinterpret_cast<LeafPage *>(node);
    LeafPage *neighbor_leaf = reinterpret_cast<LeafPage *>(neighbor_node);
    
    // 将所有元素移动到相邻节点
    leaf->MoveAllTo(neighbor_leaf);
  } else {
    InternalPage *internal = reinterpret_cast<InternalPage *>(node);
    InternalPage *neighbor_internal = reinterpret_cast<InternalPage *>(neighbor_node);
    
    // 移动所有元素，包括中间键
    internal->MoveAllTo(neighbor_internal, middle_key, buffer_pool_manager_);
  }
  
  // 从父节点删除对应条目
  parent->Remove(index);
  
  // 递归检查父节点是否需要调整
  return CoalesceOrRedistribute(parent, transaction);
}

INDEX_TEMPLATE_ARGUMENTS
template <typename N>
void BPLUSTREE_TYPE::Redistribute(N *neighbor_node, N *node,
                                  BPlusTreeInternalPage<KeyType, page_id_t, KeyComparator> *parent,
                                  int index, bool from_prev) {
  // 叶节点重新分配
  if (node->IsLeafPage()) {
    LeafPage *leaf = reinterpret_cast<LeafPage *>(node);
    LeafPage *neighbor_leaf = reinterpret_cast<LeafPage *>(neighbor_node);
    
    if (from_prev) {
      // 从前一个节点移动最后一个元素
      neighbor_leaf->MoveLastToFrontOf(leaf);
      parent->SetKeyAt(index, leaf->KeyAt(0));
    } else {
      // 从后一个节点移动第一个元素
      neighbor_leaf->MoveFirstToEndOf(leaf);
      parent->SetKeyAt(index + 1, neighbor_leaf->KeyAt(0));
    }
  } 
  // 内部节点重新分配
  else {
    InternalPage *internal = reinterpret_cast<InternalPage *>(node);
    InternalPage *neighbor_internal = reinterpret_cast<InternalPage *>(neighbor_node);
    
    if (from_prev) {
      // 从前一个内部节点移动最后一个元素
      neighbor_internal->MoveLastToFrontOf(internal, parent->KeyAt(index), buffer_pool_manager_);
      parent->SetKeyAt(index, internal->KeyAt(0));
    } else {
      // 从后一个内部节点移动第一个元素
      neighbor_internal->MoveFirstToEndOf(internal, parent->KeyAt(index + 1), buffer_pool_manager_);
      parent->SetKeyAt(index + 1, neighbor_internal->KeyAt(0));
    }
  }
}

INDEX_TEMPLATE_ARGUMENTS
auto BPLUSTREE_TYPE::AdjustRoot(BPlusTreePage *old_root_node) -> bool {
  // 处理内部根节点只有一个子节点的情况
  if (!old_root_node->IsLeafPage() && old_root_node->GetSize() == 1) {
    InternalPage *root = reinterpret_cast<InternalPage *>(old_root_node);
    page_id_t child_id = root->ValueAt(0);
    
    Page *child_page = buffer_pool_manager_->FetchPage(child_id);
    BPlusTreePage *child = reinterpret_cast<BPlusTreePage *>(child_page->GetData());
    
    // 子节点成为新的根节点
    child->SetParentPageId(INVALID_PAGE_ID);
    root_page_id_ = child->GetPageId();
    
    UpdateRootPageId(0);
    buffer_pool_manager_->UnpinPage(child_page->GetPageId(), false);
    return true;
  }
  
  // 处理空叶根节点的情况
  if (old_root_node->IsLeafPage() && old_root_node->GetSize() == 0) {
    root_page_id_ = INVALID_PAGE_ID;
    return true;
  }
  
  return false;
}

INDEX_TEMPLATE_ARGUMENTS
auto BPLUSTREE_TYPE::Begin() -> INDEXITERATOR_TYPE {
  if (root_page_id_ == INVALID_PAGE_ID) {
    return INDEXITERATOR_TYPE(nullptr, nullptr);
  }
  
  root_page_id_latch_.RLock();
  Page *leftmost_page = FindLeaf(KeyType(), Operation::SEARCH, nullptr, true);
  return INDEXITERATOR_TYPE(buffer_pool_manager_, leftmost_page, 0);
}

INDEX_TEMPLATE_ARGUMENTS
auto BPLUSTREE_TYPE::Begin(const KeyType &key) -> INDEXITERATOR_TYPE {
  if (root_page_id_ == INVALID_PAGE_ID) {
    return INDEXITERATOR_TYPE(nullptr, nullptr);
  }
  
  root_page_id_latch_.RLock();
  Page *leaf_page = FindLeaf(key, Operation::SEARCH);
  LeafPage *leaf = reinterpret_cast<LeafPage *>(leaf_page->GetData());
  int position = leaf->KeyIndex(key, comparator_);
  return INDEXITERATOR_TYPE(buffer_pool_manager_, leaf_page, position);
}

INDEX_TEMPLATE_ARGUMENTS
auto BPLUSTREE_TYPE::End() -> INDEXITERATOR_TYPE {
  if (root_page_id_ == INVALID_PAGE_ID) {
    return INDEXITERATOR_TYPE(nullptr, nullptr);
  }
  
  root_page_id_latch_.RLock();
  Page *rightmost_page = FindLeaf(KeyType(), Operation::SEARCH, nullptr, false, true);
  LeafPage *leaf = reinterpret_cast<LeafPage *>(rightmost_page->GetData());
  return INDEXITERATOR_TYPE(buffer_pool_manager_, rightmost_page, leaf->GetSize());
}

INDEX_TEMPLATE_ARGUMENTS
auto BPLUSTREE_TYPE::FindLeaf(const KeyType &key, Operation operation, Transaction *transaction, 
                              bool leftMost, bool rightMost) -> Page * {
  // 参数验证
  if (operation == Operation::SEARCH) {
    // 搜索时不能同时指定最左和最右
    if (leftMost && rightMost) {
      return nullptr;
    }
  } else {
    // 修改操作必须有事务
    if (transaction == nullptr) {
      return nullptr;
    }
  }
  
  // 从根节点开始查找
  Page *current = buffer_pool_manager_->FetchPage(root_page_id_);
  BPlusTreePage *current_node = reinterpret_cast<BPlusTreePage *>(current->GetData());
  
  // 根据操作类型获取适当的锁
  if (operation == Operation::SEARCH) {
    // 搜索：使用读锁
    root_page_id_latch_.RUnlock();
    current->RLatch();
  } else {
    // 修改：使用写锁
    current->WLatch();
    
    // 检查节点安全性，决定是否释放祖先锁
    if (operation == Operation::DELETE) {
      if (current_node->GetSize() > 2) {
        ReleaseLatchFromQueue(transaction);
      }
    } else if (operation == Operation::INSERT) {
      if (current_node->IsLeafPage()) {
        if (current_node->GetSize() < current_node->GetMaxSize() - 1) {
          ReleaseLatchFromQueue(transaction);
        }
      } else {
        if (current_node->GetSize() < current_node->GetMaxSize()) {
          ReleaseLatchFromQueue(transaction);
        }
      }
    }
  }
  
  // 向下遍历直到找到叶节点
  while (!current_node->IsLeafPage()) {
    InternalPage *internal = reinterpret_cast<InternalPage *>(current_node);
    
    // 确定下一个子节点
    page_id_t next_page_id;
    if (leftMost) {
      next_page_id = internal->ValueAt(0);
    } else if (rightMost) {
      next_page_id = internal->ValueAt(internal->GetSize() - 1);
    } else {
      next_page_id = internal->Lookup(key, comparator_);
    }
    
    // 获取子节点
    Page *next_page = buffer_pool_manager_->FetchPage(next_page_id);
    BPlusTreePage *next_node = reinterpret_cast<BPlusTreePage *>(next_page->GetData());
    
    // 处理锁
    if (operation == Operation::SEARCH) {
      // 搜索：获取子节点读锁，释放当前节点读锁
      next_page->RLatch();
      current->RUnlatch();
      buffer_pool_manager_->UnpinPage(current->GetPageId(), false);
    } else {
      // 修改：获取子节点写锁
      next_page->WLatch();
      transaction->AddIntoPageSet(current);
      
      // 检查子节点安全性
      bool is_safe = false;
      if (operation == Operation::INSERT) {
        if (next_node->IsLeafPage()) {
          is_safe = (next_node->GetSize() < next_node->GetMaxSize() - 1);
        } else {
          is_safe = (next_node->GetSize() < next_node->GetMaxSize());
        }
      } else if (operation == Operation::DELETE) {
        is_safe = (next_node->GetSize() > next_node->GetMinSize());
      }
      
      if (is_safe) {
        ReleaseLatchFromQueue(transaction);
      }
    }
    
    // 移动到子节点
    current = next_page;
    current_node = next_node;
  }
  
  return current;
}

INDEX_TEMPLATE_ARGUMENTS
void BPLUSTREE_TYPE::ReleaseLatchFromQueue(Transaction *transaction) {
  // 释放事务中保存的所有锁
  while (!transaction->GetPageSet()->empty()) {
    Page *locked_page = transaction->GetPageSet()->front();
    transaction->GetPageSet()->pop_front();
    
    if (locked_page == nullptr) {
      // nullptr 表示根锁
      root_page_id_latch_.WUnlock();
    } else {
      locked_page->WUnlatch();
      buffer_pool_manager_->UnpinPage(locked_page->GetPageId(), false);
    }
  }
}

INDEX_TEMPLATE_ARGUMENTS
auto BPLUSTREE_TYPE::GetRootPageId() -> page_id_t {
  // 简单的获取根页面ID，需要短暂获取读锁
  root_page_id_latch_.RLock();
  root_page_id_latch_.RUnlock();
  return root_page_id_;
}

INDEX_TEMPLATE_ARGUMENTS
void BPLUSTREE_TYPE::UpdateRootPageId(int insert_record) {
  // 更新或插入根页面ID到头页面
  HeaderPage *header = static_cast<HeaderPage *>(buffer_pool_manager_->FetchPage(HEADER_PAGE_ID));
  
  if (insert_record != 0) {
    header->InsertRecord(index_name_, root_page_id_);
  } else {
    header->UpdateRecord(index_name_, root_page_id_);
  }
  
  buffer_pool_manager_->UnpinPage(HEADER_PAGE_ID, true);
}

// 以下函数保持与原始代码类似，但不是核心逻辑
INDEX_TEMPLATE_ARGUMENTS
void BPLUSTREE_TYPE::InsertFromFile(const std::string &file_name, Transaction *transaction) {
  std::ifstream input(file_name);
  int64_t key_value;
  
  while (input >> key_value) {
    KeyType key;
    key.SetFromInteger(key_value);
    RID record_id(key_value);
    Insert(key, record_id, transaction);
  }
}

INDEX_TEMPLATE_ARGUMENTS
void BPLUSTREE_TYPE::RemoveFromFile(const std::string &file_name, Transaction *transaction) {
  std::ifstream input(file_name);
  int64_t key_value;
  
  while (input >> key_value) {
    KeyType key;
    key.SetFromInteger(key_value);
    Remove(key, transaction);
  }
}

INDEX_TEMPLATE_ARGUMENTS
void BPLUSTREE_TYPE::Draw(BufferPoolManager *bpm, const std::string &outf) {
  if (IsEmpty()) {
    LOG_WARN("Drawing empty tree");
    return;
  }
  
  std::ofstream output(outf);
  output << "digraph G {" << std::endl;
  
  Page *root_page = bpm->FetchPage(root_page_id_);
  BPlusTreePage *root = reinterpret_cast<BPlusTreePage *>(root_page->GetData());
  ToGraph(root, bpm, output);
  
  output << "}" << std::endl;
  output.close();
  bpm->UnpinPage(root_page->GetPageId(), false);
}

INDEX_TEMPLATE_ARGUMENTS
void BPLUSTREE_TYPE::Print(BufferPoolManager *bpm) {
  if (IsEmpty()) {
    LOG_WARN("Printing empty tree");
    return;
  }
  
  Page *root_page = bpm->FetchPage(root_page_id_);
  BPlusTreePage *root = reinterpret_cast<BPlusTreePage *>(root_page->GetData());
  ToString(root, bpm);
  bpm->UnpinPage(root_page->GetPageId(), false);
}

// 可视化函数（简化实现）
INDEX_TEMPLATE_ARGUMENTS
void BPLUSTREE_TYPE::ToGraph(BPlusTreePage *page, BufferPoolManager *bpm, std::ofstream &out) const {
  // 简化的图形生成逻辑
  if (page->IsLeafPage()) {
    LeafPage *leaf = reinterpret_cast<LeafPage *>(page);
    out << "LEAF_" << leaf->GetPageId() << " [label=\"";
    for (int i = 0; i < leaf->GetSize(); i++) {
      out << leaf->KeyAt(i);
      if (i < leaf->GetSize() - 1) out << "|";
    }
    out << "\"];" << std::endl;
  } else {
    InternalPage *internal = reinterpret_cast<InternalPage *>(page);
    out << "INTERNAL_" << internal->GetPageId() << " [label=\"";
    for (int i = 1; i < internal->GetSize(); i++) {
      out << internal->KeyAt(i);
      if (i < internal->GetSize() - 1) out << "|";
    }
    out << "\"];" << std::endl;
  }
}

INDEX_TEMPLATE_ARGUMENTS
void BPLUSTREE_TYPE::ToString(BPlusTreePage *page, BufferPoolManager *bpm) const {
  // 简化的文本输出
  if (page->IsLeafPage()) {
    LeafPage *leaf = reinterpret_cast<LeafPage *>(page);
    std::cout << "Leaf Page " << leaf->GetPageId() << ": ";
    for (int i = 0; i < leaf->GetSize(); i++) {
      std::cout << leaf->KeyAt(i) << " ";
    }
    std::cout << std::endl;
  } else {
    InternalPage *internal = reinterpret_cast<InternalPage *>(page);
    std::cout << "Internal Page " << internal->GetPageId() << ": ";
    for (int i = 1; i < internal->GetSize(); i++) {
      std::cout << internal->KeyAt(i) << " ";
    }
    std::cout << std::endl;
  }
}

template class BPlusTree<GenericKey<4>, RID, GenericComparator<4>>;
template class BPlusTree<GenericKey<8>, RID, GenericComparator<8>>;
template class BPlusTree<GenericKey<16>, RID, GenericComparator<16>>;
template class BPlusTree<GenericKey<32>, RID, GenericComparator<32>>;
template class BPlusTree<GenericKey<64>, RID, GenericComparator<64>>;

}  // namespace bustub