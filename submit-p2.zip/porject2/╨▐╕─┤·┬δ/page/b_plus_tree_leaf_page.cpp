/**
 * b_plus_tree_leaf_page.cpp
 * B+Tree 叶子结点页的实现
 */

#ifndef PAGE_SIZE
#define PAGE_SIZE 4096  // 常见的页面大小
#endif

#include <sstream>
#include <algorithm>

#include "common/exception.h"
#include "common/rid.h"
#include "common/logger.h"
#include "storage/page/b_plus_tree_leaf_page.h"
#include "storage/page/b_plus_tree_internal_page.h"

namespace bustub {

/*****************************************************************************
 * 基础工具函数
 *****************************************************************************/

/**
 * 初始化一个刚从缓冲池中分配出来的叶子页：
 * - 设置页类型
 * - 重置 size
 * - 填写 page_id / parent_id
 * - 初始化 next_page_id
 * - 计算并设置 max_size
 */
template <typename KeyType, typename ValueType, typename KeyComparator>
void BPlusTreeLeafPage<KeyType, ValueType, KeyComparator>::Init(
    page_id_t page_id, page_id_t parent_id) {
  // 标记为叶子页
  SetPageType(IndexPageType::LEAF_PAGE);
  // 此时页内还没有有效键值对
  SetSize(0);
  // 记录自身与父节点的信息
  SetPageId(page_id);
  SetParentPageId(parent_id);
  // 链表中的下一页暂时未知
  SetNextPageId(INVALID_PAGE_ID);

  // 计算可容纳的最大 KV 数量（头部 28 字节）
  int size = (PAGE_SIZE - sizeof(BPlusTreeLeafPage)) /
             (sizeof(KeyType) + sizeof(ValueType));
  SetMaxSize(size);
}

/** 获取链表中下一个叶子页的页号 */
template <typename KeyType, typename ValueType, typename KeyComparator>
page_id_t
BPlusTreeLeafPage<KeyType, ValueType, KeyComparator>::GetNextPageId() const {
  return next_page_id_;
}

/** 设置下一个叶子页的页号 */
template <typename KeyType, typename ValueType, typename KeyComparator>
void BPlusTreeLeafPage<KeyType, ValueType, KeyComparator>::SetNextPageId(
    page_id_t next_page_id) {
  next_page_id_ = next_page_id;
}

/**
 * 用于迭代器：找到第一个满足 array[i].first >= key 的下标
 */
template <typename KeyType, typename ValueType, typename KeyComparator>
int BPlusTreeLeafPage<KeyType, ValueType, KeyComparator>::KeyIndex(
    const KeyType &key, const KeyComparator &comparator) const {
  for (int i = 0; i < GetSize(); ++i) {
    if (comparator(key, array[i].first) <= 0) {
      return i;
    }
  }
  return GetSize();
}

/** 根据下标取出对应的 key */
template <typename KeyType, typename ValueType, typename KeyComparator>
KeyType BPlusTreeLeafPage<KeyType, ValueType, KeyComparator>::KeyAt(
    int index) const {
  assert(0 <= index && index < GetSize());
  return array[index].first;
}

template <typename KeyType, typename ValueType, typename KeyComparator>
void BPlusTreeLeafPage<KeyType, ValueType, KeyComparator>::SetKeyAt(int index, const KeyType &key){ 
    array[index].first = key; 
}

template <typename KeyType, typename ValueType, typename KeyComparator>
  void BPlusTreeLeafPage<KeyType, ValueType, KeyComparator>::SetValueAt(int index, const ValueType &value){ 
    array[index].second = value; 
}

template <typename KeyType, typename ValueType, typename KeyComparator>
  ValueType BPlusTreeLeafPage<KeyType, ValueType, KeyComparator>::ValueAt(int index) const{ 
    return array[index].second; 
}

/** 根据下标返回一对 <key, value> 映射 */
template <typename KeyType, typename ValueType, typename KeyComparator>
const MappingType &
BPlusTreeLeafPage<KeyType, ValueType, KeyComparator>::GetItem(int index) {
  assert(0 <= index && index < GetSize());
  return array[index];
}







/*****************************************************************************
 * 插入
 *****************************************************************************/

/**
 * 将 <key, value> 插入叶子页中，保持 key 有序，不允许重复键
 * @return 插入后的页面 size
 */
template <typename KeyType, typename ValueType, typename KeyComparator>
int BPlusTreeLeafPage<KeyType, ValueType, KeyComparator>::Insert(
    const KeyType &key, const ValueType &value,
    const KeyComparator &comparator) {
  // 1）空页或插在末尾（比当前最大 key 还大）
  if (GetSize() == 0 || comparator(key, KeyAt(GetSize() - 1)) > 0) {
    array[GetSize()] = {key, value};
  }
  // 2）插在最前面（比当前最小 key 还小）
  else if (comparator(key, array[0].first) < 0) {
    //改为std::move_backward
    std::move_backward(array, array + GetSize(), array + GetSize() + 1);
    array[0] = {key, value};
  }
  // 3）其余情况二分查找插入位置
  else {
    int low = 0, high = GetSize() - 1, mid;
    while (low < high && low + 1 != high) {
      mid = low + (high - low) / 2;
      if (comparator(key, array[mid].first) < 0) {
        high = mid;
      } else if (comparator(key, array[mid].first) > 0) {
        low = mid;
      } else {
        // 只支持唯一 key，不应该走到这里
        assert(0);
      }
    }

    //改为std::move_backward
    std::move_backward(array + high, array + GetSize(), array + GetSize() + 1);
    array[high] = {key, value};
  }

  IncreaseSize(1);
  assert(GetSize() <= GetMaxSize());
  return GetSize();
}

/*****************************************************************************
 * 分裂
 *****************************************************************************/

/**
 * 将当前页后半部分的键值对移动到 recipient 中
 */
template <typename KeyType, typename ValueType, typename KeyComparator>
void BPlusTreeLeafPage<KeyType, ValueType, KeyComparator>::MoveHalfTo(
    BPlusTreeLeafPage *recipient,
    __attribute__((unused)) BufferPoolManager *buffer_pool_manager) {
  assert(GetSize() > 0);

  int move_count = GetSize() / 2;
  MappingType *src = array + GetSize() - move_count;
  recipient->CopyHalfFrom(src, move_count);
  IncreaseSize(-1 * move_count);
}

/** recipient 从给定数组中拷贝 size 个元素 */
template <typename KeyType, typename ValueType, typename KeyComparator>
void BPlusTreeLeafPage<KeyType, ValueType, KeyComparator>::CopyHalfFrom(
    MappingType *items, int size) {
  assert(IsLeafPage() && GetSize() == 0);
  for (int i = 0; i < size; ++i) {
    array[i] = *items++;
  }
  IncreaseSize(size);
}

/*****************************************************************************
 * 查找
 *****************************************************************************/

/**
 * 在叶子页中查找 key 对应的 value
 * 如果找到，将 value 写入参数并返回 true；否则返回 false
 */
template <typename KeyType, typename ValueType, typename KeyComparator>
bool BPlusTreeLeafPage<KeyType, ValueType, KeyComparator>::Lookup(
    const KeyType &key, ValueType &value,
    const KeyComparator &comparator) const {
  // 先做一次范围排除
  if (GetSize() == 0 || comparator(key, KeyAt(0)) < 0 ||
      comparator(key, KeyAt(GetSize() - 1)) > 0) {
    return false;
  }

  // 二分查找
  int low = 0, high = GetSize() - 1, mid;
  while (low <= high) {
    mid = low + (high - low) / 2;
    if (comparator(key, KeyAt(mid)) > 0) {
      low = mid + 1;
    } else if (comparator(key, KeyAt(mid)) < 0) {
      high = mid - 1;
    } else {
      value = array[mid].second;
      return true;
    }
  }
  return false;
}

/*****************************************************************************
 * 删除
 *****************************************************************************/

/**
 * 如果 key 存在于当前页，则删除对应的 KV，并保持数组连续
 * @return 删除操作完成后的 size
 */
template <typename KeyType, typename ValueType, typename KeyComparator>
int BPlusTreeLeafPage<KeyType, ValueType, KeyComparator>::RemoveAndDeleteRecord(
    const KeyType &key, const KeyComparator &comparator) {
  // 一样先检查范围
  if (GetSize() == 0 || comparator(key, KeyAt(0)) < 0 ||
      comparator(key, KeyAt(GetSize() - 1)) > 0) {
    return GetSize();
  }

  int low = 0, high = GetSize() - 1, mid;
  while (low <= high) {
    mid = low + (high - low) / 2;
    if (comparator(key, KeyAt(mid)) > 0) {
      low = mid + 1;
    } else if (comparator(key, KeyAt(mid)) < 0) {
      high = mid - 1;
    } else {
      // 找到后用 memmove 覆盖该位置
      //改为std::move
      std::move(array + mid + 1, array + GetSize(), array + mid);
      IncreaseSize(-1);
      break;
    }
  }
  return GetSize();
}

/*****************************************************************************
 * 合并
 *****************************************************************************/

/**
 * 将当前页所有 KV 移动到 recipient，随后由外部更新链指针
 */
template <typename KeyType, typename ValueType, typename KeyComparator>
void BPlusTreeLeafPage<KeyType, ValueType, KeyComparator>::MoveAllTo(
    BPlusTreeLeafPage *recipient, int, BufferPoolManager *) {
  recipient->CopyAllFrom(array, GetSize());
  recipient->SetNextPageId(GetNextPageId());
}

/** recipient 在尾部追加 size 个 elements */
template <typename KeyType, typename ValueType, typename KeyComparator>
void BPlusTreeLeafPage<KeyType, ValueType, KeyComparator>::CopyAllFrom(
    MappingType *items, int size) {
  assert(GetSize() + size <= GetMaxSize());
  auto start = GetSize();
  for (int i = 0; i < size; ++i) {
    array[start + i] = *items++;
  }
  IncreaseSize(size);
}

/*****************************************************************************
 * 重分配（借 key）
 *****************************************************************************/

/**
 * 将当前页的第一个 KV 移动到 recipient 的末尾，并修改父节点相关键值
 */
template <typename KeyType, typename ValueType, typename KeyComparator>
void BPlusTreeLeafPage<KeyType, ValueType, KeyComparator>::MoveFirstToEndOf(
    BPlusTreeLeafPage *recipient, BufferPoolManager *buffer_pool_manager) {
  MappingType pair = GetItem(0);
  IncreaseSize(-1);
  //改为std::move
  std::move(array + 1, array + GetSize(), array);
  recipient->CopyLastFrom(pair);

  auto *page = buffer_pool_manager->FetchPage(GetParentPageId());
  if (page == nullptr) {
    throw Exception(
                    "all page are pinned while MoveFirstToEndOf");
  }

  auto parent =
      reinterpret_cast<BPlusTreeInternalPage<KeyType, decltype(GetPageId()),
                                             KeyComparator> *>(page->GetData());

  parent->SetKeyAt(parent->ValueIndex(GetPageId()), pair.first);

  buffer_pool_manager->UnpinPage(GetParentPageId(), true);
}

/** recipient 在尾部追加一个 KV */
template <typename KeyType, typename ValueType, typename KeyComparator>
void BPlusTreeLeafPage<KeyType, ValueType, KeyComparator>::CopyLastFrom(
    const MappingType &item) {
  assert(GetSize() + 1 <= GetMaxSize());
  array[GetSize()] = item;
  IncreaseSize(1);
}

/**
 * 将当前页的最后一个 KV 挪到 recipient 的头部，并更新 parent
 */
template <typename KeyType, typename ValueType, typename KeyComparator>
void BPlusTreeLeafPage<KeyType, ValueType, KeyComparator>::MoveLastToFrontOf(
    BPlusTreeLeafPage *recipient, int parentIndex,
    BufferPoolManager *buffer_pool_manager) {
  MappingType pair = GetItem(GetSize() - 1);
  IncreaseSize(-1);
  recipient->CopyFirstFrom(pair, parentIndex, buffer_pool_manager);
}

/** recipient 在头部插入一个 KV，并同步父节点 key */
template <typename KeyType, typename ValueType, typename KeyComparator>
void BPlusTreeLeafPage<KeyType, ValueType, KeyComparator>::CopyFirstFrom(
    const MappingType &item, int parentIndex,
    BufferPoolManager *buffer_pool_manager) {
  assert(GetSize() + 1 < GetMaxSize());
  //改为std::move
  std::move_backward(array, array + GetSize(), array + GetSize() + 1);
  IncreaseSize(1);
  array[0] = item;

  auto *page = buffer_pool_manager->FetchPage(GetParentPageId());
  if (page == nullptr) {
    throw Exception(
                    "all page are pinned while CopyFirstFrom");
  }

  auto parent =
      reinterpret_cast<BPlusTreeInternalPage<KeyType, decltype(GetPageId()),
                                             KeyComparator> *>(page->GetData());

  parent->SetKeyAt(parentIndex, item.first);

  buffer_pool_manager->UnpinPage(GetParentPageId(), true);
}

/*****************************************************************************
 * 调试输出
 *****************************************************************************/
template <typename KeyType, typename ValueType, typename KeyComparator>
std::string BPlusTreeLeafPage<KeyType, ValueType, KeyComparator>::ToString(
    bool verbose) const {
  if (GetSize() == 0) {
    return "";
  }
  std::ostringstream stream;
  if (verbose) {
    stream << "[" << GetPageId() << "-" << GetParentPageId() << "]";
  }
  int entry = 0;
  int end = GetSize();
  bool first = true;

  while (entry < end) {
    if (first) {
      first = false;
    } else {
      stream << " ";
    }
    stream << std::dec << " " << array[entry].first;
    if (verbose) {
      stream << " (" << array[entry].second << ")";
    }
    ++entry;
    stream << " ";
  }
  return stream.str();
}

template class BPlusTreeLeafPage<GenericKey<4>, RID, GenericComparator<4>>;
template class BPlusTreeLeafPage<GenericKey<8>, RID, GenericComparator<8>>;
template class BPlusTreeLeafPage<GenericKey<16>, RID, GenericComparator<16>>;
template class BPlusTreeLeafPage<GenericKey<32>, RID, GenericComparator<32>>;
template class BPlusTreeLeafPage<GenericKey<64>, RID, GenericComparator<64>>;

} // namespace bustub
