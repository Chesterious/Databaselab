/**
 * b_plus_tree_internal_page.cpp
 * B+Tree 内部结点页的实现
 */

#ifndef PAGE_SIZE
#define PAGE_SIZE 4096  // 常见的页面大小
#endif


#include <iostream>
#include <sstream>
#include <algorithm>

#include "common/exception.h"
#include "storage/page/b_plus_tree_internal_page.h"

namespace bustub {

/*****************************************************************************
 * 基础工具函数
 *****************************************************************************/

/**
 * 初始化一个内部页：
 * - 设置页类型为 INTERNAL
 * - 初始化 size
 * - 记录 page_id / parent_id
 * - 计算最大容量
 */
template <typename KeyType, typename ValueType, typename KeyComparator>
void BPlusTreeInternalPage<KeyType, ValueType, KeyComparator>::Init(
    page_id_t page_id, page_id_t parent_id) {
  SetPageType(IndexPageType::INTERNAL_PAGE);
  // 内部节点 0 号位置存无效 key，但有有效 value，因此初始化 size 为 1
  SetSize(1);
  SetPageId(page_id);
  SetParentPageId(parent_id);

  int size = (PAGE_SIZE - sizeof(BPlusTreeInternalPage)) /
             (sizeof(KeyType) + sizeof(ValueType));
  SetMaxSize(size);
}

/** 根据下标读取 key */
template <typename KeyType, typename ValueType, typename KeyComparator>
KeyType BPlusTreeInternalPage<KeyType, ValueType, KeyComparator>::KeyAt(
    int index) const {
  assert(0 <= index && index < GetSize());
  return array[index].first;
}

/** 写入指定下标的 key */
template <typename KeyType, typename ValueType, typename KeyComparator>
void BPlusTreeInternalPage<KeyType, ValueType, KeyComparator>::SetKeyAt(
    int index, const KeyType &key) {
  assert(0 <= index && index < GetSize());
  array[index].first = key;
}

/**
 * 在当前页中查找给定 value 对应的索引
 * 若未找到则返回 GetSize()
 */
template <typename KeyType, typename ValueType, typename KeyComparator>
int BPlusTreeInternalPage<KeyType, ValueType, KeyComparator>::ValueIndex(
    const ValueType &value) const {
  for (int i = 0; i < GetSize(); ++i) {
    if (array[i].second == value) {
      return i;
    }
  }
  return GetSize();
}

/** 根据数组下标取得 value（page_id） */
template <typename KeyType, typename ValueType, typename KeyComparator>
ValueType BPlusTreeInternalPage<KeyType, ValueType, KeyComparator>::ValueAt(
    int index) const {
  assert(0 <= index && index < GetSize());
  return array[index].second;
}

/** 修改指定位置的 value */
template <typename KeyType, typename ValueType, typename KeyComparator>
void BPlusTreeInternalPage<KeyType, ValueType, KeyComparator>::SetValueAt(
    int index, const ValueType &value) {
  assert(0 <= index && index < GetSize());
  array[index].second = value;
}

/*****************************************************************************
 * 查找
 *****************************************************************************/

/**
 * 根据 key 选择要下降到哪个子页：
 * - 0 号位置的 key 无效，但其 value 是最左孩子
 * - 其余位置存有效 <key, child>，搜索从下标 1 开始
 */
template <typename KeyType, typename ValueType, typename KeyComparator>
ValueType BPlusTreeInternalPage<KeyType, ValueType, KeyComparator>::Lookup(
    const KeyType &key, const KeyComparator &comparator) const {
  assert(GetSize() > 1);

  // 对最左和最右做一次边界判断
  if (comparator(key, array[1].first) < 0) {
    return array[0].second;
  } else if (comparator(key, array[GetSize() - 1].first) >= 0) {
    return array[GetSize() - 1].second;
  }

  // 在 (1, size-1) 范围内做二分
  int low = 1, high = GetSize() - 1, mid;
  while (low < high && low + 1 != high) {
    mid = low + (high - low) / 2;
    if (comparator(key, array[mid].first) < 0) {
      high = mid;
    } else if (comparator(key, array[mid].first) > 0) {
      low = mid;
    } else {
      return array[mid].second;
    }
  }
  return array[low].second;
}

/*****************************************************************************
 * 插入
 *****************************************************************************/

/**
 * 当原根节点分裂，创建新的根节点时调用
 * 在空的根节点（实际上只有一个 0 号 child）中填入：
 *   [0] : old_value
 *   [1] : <new_key, new_value>
 */
template <typename KeyType, typename ValueType, typename KeyComparator>
void BPlusTreeInternalPage<KeyType, ValueType, KeyComparator>::PopulateNewRoot(
    const ValueType &old_value, const KeyType &new_key,
    const ValueType &new_value) {
  // root 初始化时 size 为 1，只存一个 child
  assert(GetSize() == 1);
  array[0].second = old_value;
  array[1] = {new_key, new_value};
  IncreaseSize(1);
}

/**
 * 在 value == old_value 的项之后插入一对 <new_key, new_value>
 * @return 插入后的 size
 */
template <typename KeyType, typename ValueType, typename KeyComparator>
int BPlusTreeInternalPage<KeyType, ValueType, KeyComparator>::InsertNodeAfter(
    const ValueType &old_value, const KeyType &new_key,
    const ValueType &new_value) {
  for (int i = GetSize(); i > 0; --i) {
    if (array[i - 1].second == old_value) {
      array[i] = {new_key, new_value};
      IncreaseSize(1);
      break;
    }
    array[i] = array[i - 1];
  }
  return GetSize();
}

/*****************************************************************************
 * 分裂
 *****************************************************************************/

/**
 * 将当前页后半部分的键值对移动到 recipient
 * 同时更新这些子节点的 parent_page_id
 */
template <typename KeyType, typename ValueType, typename KeyComparator>
void BPlusTreeInternalPage<KeyType, ValueType, KeyComparator>::MoveHalfTo(
    BPlusTreeInternalPage *recipient,
    BufferPoolManager *buffer_pool_manager) {
  auto half = (GetSize() + 1) / 2;
  recipient->CopyHalfFrom(array + GetSize() - half, half, buffer_pool_manager);

  // 更新被移走子节点的父指针
  for (auto index = GetSize() - half; index < GetSize(); ++index) {
    auto *page = buffer_pool_manager->FetchPage(ValueAt(index));
    if (page == nullptr) {
      throw Exception(
                      "all page are pinned while CopyLastFrom");
    }
    auto child = reinterpret_cast<BPlusTreePage *>(page->GetData());
    child->SetParentPageId(recipient->GetPageId());
    assert(child->GetParentPageId() == recipient->GetPageId());
    buffer_pool_manager->UnpinPage(child->GetPageId(), true);
  }
  IncreaseSize(-1 * half);
}

/**
 * recipient 从给定数组中拷贝 size 个元素
 * 注意：内部分裂时，左边的中间 key 会被提升，因此 size 里包含一个无效项
 */
template <typename KeyType, typename ValueType, typename KeyComparator>
void BPlusTreeInternalPage<KeyType, ValueType, KeyComparator>::CopyHalfFrom(
    MappingType *items, int size, BufferPoolManager *buffer_pool_manager) {
  assert(!IsLeafPage() && GetSize() == 1 && size > 0);
  (void)buffer_pool_manager;
  for (int i = 0; i < size; ++i) {
    array[i] = *items++;
  }
  IncreaseSize(size - 1);
}

/*****************************************************************************
 * 删除
 *****************************************************************************/

/**
 * 删除指定下标位置的键值对，并将后面的内容整体前移保持连续
 */
template <typename KeyType, typename ValueType, typename KeyComparator>
void BPlusTreeInternalPage<KeyType, ValueType, KeyComparator>::Remove(
    int index) {
  assert(0 <= index && index < GetSize());
  for (int i = index; i < GetSize() - 1; ++i) {
    array[i] = array[i + 1];
  }
  IncreaseSize(-1);
}

/**
 * 当内部页只剩下一个键值对时，将其唯一的 child 返回
 * 调整根节点时会用到
 */
template <typename KeyType, typename ValueType, typename KeyComparator>
ValueType
BPlusTreeInternalPage<KeyType, ValueType, KeyComparator>::RemoveAndReturnOnlyChild() {
  IncreaseSize(-1);
  assert(GetSize() == 1);
  return ValueAt(0);
}

/*****************************************************************************
 * 合并
 *****************************************************************************/

/**
 * 将当前页所有内容移动到 recipient，然后修正相关子节点父指针
 * parent 中 index_in_parent 对应的 key 会被下推到本页 0 号位置
 */
template <typename KeyType, typename ValueType, typename KeyComparator>
void BPlusTreeInternalPage<KeyType, ValueType, KeyComparator>::MoveAllTo(
    BPlusTreeInternalPage *recipient, int index_in_parent,
    BufferPoolManager *buffer_pool_manager) {
  // 拿到父节点
  auto *page = buffer_pool_manager->FetchPage(GetParentPageId());
  if (page == nullptr) {
    throw Exception(
                    "all page are pinned while MoveAllTo");
  }
  auto *parent = reinterpret_cast<BPlusTreeInternalPage *>(page->GetData());

  // 把父节点的分隔 key 下推到本页
  SetKeyAt(0, parent->KeyAt(index_in_parent));
  assert(parent->ValueAt(index_in_parent) == GetPageId());
  buffer_pool_manager->UnpinPage(parent->GetPageId(), true);

  // 将所有内容复制到 recipient
  recipient->CopyAllFrom(array, GetSize(), buffer_pool_manager);

  // 更新这些孩子的父指针
  for (auto index = 0; index < GetSize(); ++index) {
    auto *child_page =
        buffer_pool_manager->FetchPage(ValueAt(index));
    if (child_page == nullptr) {
      throw Exception(
                      "all page are pinned while CopyLastFrom");
    }
    auto child = reinterpret_cast<BPlusTreePage *>(child_page->GetData());
    child->SetParentPageId(recipient->GetPageId());
    assert(child->GetParentPageId() == recipient->GetPageId());
    buffer_pool_manager->UnpinPage(child->GetPageId(), true);
  }
}

/** recipient 在尾部追加 size 个元素 */
template <typename KeyType, typename ValueType, typename KeyComparator>
void BPlusTreeInternalPage<KeyType, ValueType, KeyComparator>::CopyAllFrom(
    MappingType *items, int size, BufferPoolManager *buffer_pool_manager) {
  (void)buffer_pool_manager;
  assert(GetSize() + size <= GetMaxSize());
  int start = GetSize();
  for (int i = 0; i < size; ++i) {
    array[start + i] = *items++;
  }
  IncreaseSize(size);
}

/*****************************************************************************
 * 重分配（借兄弟节点的子树）
 *****************************************************************************/

/**
 * 将当前页最左边的 child 挪到 recipient 的最右边
 * 同时修正 parent 与 child 的相关 key
 */
template <typename KeyType, typename ValueType, typename KeyComparator>
void BPlusTreeInternalPage<KeyType, ValueType, KeyComparator>::MoveFirstToEndOf(
    BPlusTreeInternalPage *recipient,
    BufferPoolManager *buffer_pool_manager) {
  assert(GetSize() > 1);
  MappingType pair{KeyAt(1), ValueAt(0)};
  page_id_t child_page_id = ValueAt(0);
  SetValueAt(0, ValueAt(1));
  Remove(1);

  recipient->CopyLastFrom(pair, buffer_pool_manager);

  // 更新子节点的父指针
  auto *page = buffer_pool_manager->FetchPage(child_page_id);
  if (page == nullptr) {
    throw Exception(
                    "all page are pinned while CopyLastFrom");
  }
  auto child = reinterpret_cast<BPlusTreePage *>(page->GetData());
  child->SetParentPageId(recipient->GetPageId());
  assert(child->GetParentPageId() == recipient->GetPageId());
  buffer_pool_manager->UnpinPage(child->GetPageId(), true);
}

/**
 * recipient 在尾部插入一个 child，并同步父节点 key
 */
template <typename KeyType, typename ValueType, typename KeyComparator>
void BPlusTreeInternalPage<KeyType, ValueType, KeyComparator>::CopyLastFrom(
    const MappingType &pair, BufferPoolManager *buffer_pool_manager) {
  assert(GetSize() + 1 <= GetMaxSize());

  auto *page = buffer_pool_manager->FetchPage(GetParentPageId());
  if (page == nullptr) {
    throw Exception(
                    "all page are pinned while CopyLastFrom");
  }
  auto parent = reinterpret_cast<BPlusTreeInternalPage *>(page->GetData());

  auto index = parent->ValueIndex(GetPageId());
  auto key = parent->KeyAt(index + 1);

  array[GetSize()] = {key, pair.second};
  IncreaseSize(1);
  parent->SetKeyAt(index + 1, pair.first);

  buffer_pool_manager->UnpinPage(parent->GetPageId(), true);
}

/**
 * 将当前页最右边的 child 挪到 recipient 的最左边
 * 并根据 parent_index 更新父节点对应的 key
 */
template <typename KeyType, typename ValueType, typename KeyComparator>
void BPlusTreeInternalPage<KeyType, ValueType, KeyComparator>::MoveLastToFrontOf(
    BPlusTreeInternalPage *recipient, int parent_index,
    BufferPoolManager *buffer_pool_manager) {
  assert(GetSize() > 1);
  IncreaseSize(-1);
  MappingType pair = array[GetSize()];
  page_id_t child_page_id = pair.second;

  recipient->CopyFirstFrom(pair, parent_index, buffer_pool_manager);

  // 修正 child 的父指针
  auto *page = buffer_pool_manager->FetchPage(child_page_id);
  if (page == nullptr) {
    throw Exception(
                    "all page are pinned while CopyLastFrom");
  }
  auto child = reinterpret_cast<BPlusTreePage *>(page->GetData());
  child->SetParentPageId(recipient->GetPageId());
  assert(child->GetParentPageId() == recipient->GetPageId());
  buffer_pool_manager->UnpinPage(child->GetPageId(), true);
}

/**
 * recipient 在头部插入 child，并根据 parent_index 更新父节点 key
 */
template <typename KeyType, typename ValueType, typename KeyComparator>
void BPlusTreeInternalPage<KeyType, ValueType, KeyComparator>::CopyFirstFrom(
    const MappingType &pair, int parent_index,
    BufferPoolManager *buffer_pool_manager) {
  assert(GetSize() + 1 < GetMaxSize());

  auto *page = buffer_pool_manager->FetchPage(GetParentPageId());
  if (page == nullptr) {
    throw Exception(
                    "all page are pinned while CopyFirstFrom");
  }
  auto parent = reinterpret_cast<BPlusTreeInternalPage *>(page->GetData());

  auto key = parent->KeyAt(parent_index);
  parent->SetKeyAt(parent_index, pair.first);

  InsertNodeAfter(array[0].second, key, array[0].second);
  array[0].second = pair.second;

  buffer_pool_manager->UnpinPage(parent->GetPageId(), true);
}

/*****************************************************************************
 * 调试相关
 *****************************************************************************/

template <typename KeyType, typename ValueType, typename KeyComparator>
void BPlusTreeInternalPage<KeyType, ValueType, KeyComparator>::QueueUpChildren(
    std::queue<BPlusTreePage *> *queue,
    BufferPoolManager *buffer_pool_manager) {
  for (int i = 0; i < GetSize(); i++) {
    auto *page = buffer_pool_manager->FetchPage(array[i].second);
    if (page == nullptr) {
      throw Exception(
                      "all page are pinned while printing");
    }
    auto *child = reinterpret_cast<BPlusTreePage *>(page->GetData());
    assert(child->GetParentPageId() == GetPageId());
    queue->push(child);
  }
}

/** 打印内部节点内容，主要用于调试 */
template <typename KeyType, typename ValueType, typename KeyComparator>
std::string BPlusTreeInternalPage<KeyType, ValueType, KeyComparator>::ToString(
    bool verbose) const {
  if (GetSize() == 0) {
    return "";
  }
  std::ostringstream os;
  if (verbose) {
    os << "[" << GetPageId() << "-" << GetParentPageId() << "]";
  }
  int entry = verbose ? 0 : 1;
  int end = GetSize();
  bool first = true;
  while (entry < end) {
    if (first) {
      first = false;
    } else {
      os << " ";
    }
    os << std::dec << " " << array[entry].first.ToString();
    if (verbose) {
      os << "(" << array[entry].second << ")";
    }
    ++entry;
    os << " ";
  }
  return os.str();
}

// valuetype for internalNode should be page id_t
template class BPlusTreeInternalPage<GenericKey<4>, page_id_t,
                                     GenericComparator<4>>;
template class BPlusTreeInternalPage<GenericKey<8>, page_id_t,
                                     GenericComparator<8>>;
template class BPlusTreeInternalPage<GenericKey<16>, page_id_t,
                                     GenericComparator<16>>;
template class BPlusTreeInternalPage<GenericKey<32>, page_id_t,
                                     GenericComparator<32>>;
template class BPlusTreeInternalPage<GenericKey<64>, page_id_t,
                                     GenericComparator<64>>;

} // namespace bustub
