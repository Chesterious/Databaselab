#pragma once
#ifndef LEAF_PAGE_SIZE
#define LEAF_PAGE_SIZE 512  // 或者其他合适的值
#endif

#ifndef INTERNAL_PAGE_SIZE  
#define INTERNAL_PAGE_SIZE 512  // 通常与叶子节点大小相同
#endif


#include <cassert>
#include <climits>
#include <cstdlib>
#include <string>

// 先包含基础类型定义的头文件
#include "common/config.h"  // 这个文件可能定义了 page_id_t
#include "storage/page/page.h"  // 或者这个文件定义了 page_id_t
#include "buffer/buffer_pool_manager.h"
#include "storage/index/generic_key.h"

namespace bustub  {

#define MappingType std::pair<KeyType, ValueType>

#define INDEX_TEMPLATE_ARGUMENTS                                               \
  template <typename KeyType, typename ValueType, typename KeyComparator>

/** B+Tree 结点类型 */
enum class IndexPageType { INVALID_INDEX_PAGE = 0, LEAF_PAGE, INTERNAL_PAGE };

/**
 * 抽象基类：
 * 只维护所有 B+Tree 结点页都共有的头部信息
 */
class BPlusTreePage {
public:
  /** 当前页是否是叶子页 */
  bool IsLeafPage() const;

  /** 当前页是否是根结点（没有父结点） */
  bool IsRootPage() const;

  /** 配置页的类别（叶子 / 内部） */
  void SetPageType(IndexPageType page_type);

  /** 已存储的键值对数量 */
  int GetSize() const;
  void SetSize(int size);
  void IncreaseSize(int amount);

  /** 页的最大容量（单位：键值对个数） */
  int GetMaxSize() const;
  void SetMaxSize(int max_size);

  /** 一般意义上的最小安全 size（通常为 Max / 2） */
  int GetMinSize() const;

  /** 获取 / 设置父结点页号 */
  page_id_t GetParentPageId() const;
  void SetParentPageId(page_id_t parent_page_id);

  /** 获取 / 设置当前页号 */
  page_id_t GetPageId() const;
  void SetPageId(page_id_t page_id);

  /** 更新日志序列号 LSN */
  void SetLSN(lsn_t lsn = INVALID_LSN);

private:
  // 下面这些字段为所有 B+Tree 结点页共享的头部信息
  IndexPageType page_type_;   // 结点类型（叶子 / 内部）
  lsn_t lsn_;                 // 日志序列号
  int size_;                  // 当前元素个数
  int max_size_;              // 最大允许元素个数
  page_id_t parent_page_id_;  // 父页页号
  page_id_t page_id_;         // 自身页号
};

} // namespace bustub
