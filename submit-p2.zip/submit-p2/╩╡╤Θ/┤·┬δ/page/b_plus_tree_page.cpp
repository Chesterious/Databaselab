/**
 * b_plus_tree_page.cpp
 * 基类 BPlusTreePage 的简单工具函数实现
 */

#ifndef PAGE_SIZE
#define PAGE_SIZE 4096  // 常见的页面大小
#endif

#include <algorithm>
#include "storage/page/b_plus_tree_page.h"

namespace bustub {

/** 判断当前页是否为叶子页 */
bool BPlusTreePage::IsLeafPage() const {
  return page_type_ == IndexPageType::LEAF_PAGE;
}

/** 根结点的特征：没有父结点 */
bool BPlusTreePage::IsRootPage() const {
  return parent_page_id_ == INVALID_PAGE_ID;
}

/** 设置页的类型（叶子页 / 内部页） */
void BPlusTreePage::SetPageType(IndexPageType page_type) {
  page_type_ = page_type;
}

/** 当前保存的键值对数量 */
int BPlusTreePage::GetSize() const { return size_; }

/** 直接覆盖当前 size */
void BPlusTreePage::SetSize(int size) { size_ = size; }

/** 在当前 size 上做增量更新 */
void BPlusTreePage::IncreaseSize(int amount) { size_ += amount; }

/** 页可以容纳的最大键值对数量（capacity） */
int BPlusTreePage::GetMaxSize() const { return max_size_; }

/** 设置页面的最大容量 */
void BPlusTreePage::SetMaxSize(int size) { max_size_ = size; }

/**
 * 返回最小允许的 size
 * 一般取 max_size 的一半
 */
int BPlusTreePage::GetMinSize() const { return max_size_ / 2; }

/** 读取父结点页号 */
page_id_t BPlusTreePage::GetParentPageId() const { return parent_page_id_; }

/** 修改父结点页号 */
void BPlusTreePage::SetParentPageId(page_id_t parent_page_id) {
  parent_page_id_ = parent_page_id;
}

/** 当前页的页号 */
page_id_t BPlusTreePage::GetPageId() const { return page_id_; }

/** 设置当前页的页号 */
void BPlusTreePage::SetPageId(page_id_t page_id) { page_id_ = page_id; }

/** 写入日志序列号 LSN */
void BPlusTreePage::SetLSN(lsn_t lsn) { lsn_ = lsn; }

} // namespace bustub
